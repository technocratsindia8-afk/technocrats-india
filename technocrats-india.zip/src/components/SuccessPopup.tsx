import { motion, AnimatePresence } from "motion/react";
import { Check } from "lucide-react";

interface SuccessPopupProps {
  message: string | null;
  onClose: () => void;
}

export default function SuccessPopup({ message, onClose }: SuccessPopupProps) {
  return (
    <AnimatePresence>
      {message && (
        <div id="success-popup-wrapper" className="fixed inset-0 flex items-center justify-center z-[99999] px-4">
          {/* Backdrop screen */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 pointer-events-auto"
          />

          {/* Modal cardboard */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            className="bg-[#111827] border border-gray-800 rounded-3xl p-6 text-center max-w-sm w-full shadow-2xl relative z-10"
          >
            {/* Success icon checkmark */}
            <motion.div
              initial={{ scale: 0.5, rotate: -45 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.1, type: "spring", stiffness: 200 }}
              className="w-20 h-80 max-h-20 bg-gradient-to-tr from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 text-white shadow-lg shadow-green-500/20"
            >
              <Check className="w-10 h-10" />
            </motion.div>

            <h3 className="text-2xl font-bold text-white mb-2 tracking-tight">
              Success!
            </h3>

            <p className="text-gray-400 text-sm leading-relaxed mb-4">
              {message}
            </p>

            <button
              id="success-popup-ok"
              onClick={onClose}
              className="py-2.5 px-6 bg-gray-800 hover:bg-gray-700/80 text-white font-medium rounded-xl text-sm transition-colors cursor-pointer select-none"
            >
              Done
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
