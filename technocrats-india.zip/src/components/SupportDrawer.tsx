import { useState, ChangeEvent, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Send, User, Mail, Phone, MessageSquare, Loader2 } from "lucide-react";
import { SupportTicket } from "../types";

interface SupportDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (message: string) => void;
}

export default function SupportDrawer({ isOpen, onClose, onSuccess }: SupportDrawerProps) {
  const [formData, setFormState] = useState<SupportTicket>({
    name: "",
    email: "",
    phone: "",
    message: ""
  });
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormState(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.phone || !formData.message) {
      return;
    }

    setSubmitting(true);

    try {
      const scriptURL = "https://script.google.com/macros/s/AKfycbydA9RRXSCyYnza6c0LKRtEje8HUJQ4spjMX_RNYGUXAvpQK98GeWUe1bswF9GwPYiM/exec";
      
      const formPayload = new FormData();
      formPayload.append("name", formData.name);
      formPayload.append("email", formData.email);
      formPayload.append("phone", formData.phone);
      formPayload.append("message", formData.message);
      formPayload.append("formType", "Support");

      const fetchPromise = fetch(scriptURL, {
        method: "POST",
        body: formPayload,
        mode: "no-cors"
      });

      await Promise.all([
        fetchPromise,
        new Promise(resolve => setTimeout(resolve, 1500))
      ]);

      setFormState({
        name: "",
        email: "",
        phone: "",
        message: ""
      });

      onClose();
      onSuccess("Support Request Submitted Successfully! Our helpdesk will contact you shortly.");
    } catch (err) {
      console.error(err);
      onClose();
      onSuccess("Support Request Submitted!");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            id="support-drawer-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.65 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black z-50 pointer-events-auto"
          />

          {/* Slide list */}
          <motion.div
            id="support-drawer-panel"
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 350 }}
            className="fixed left-0 right-0 bottom-0 bg-[#0f172a] rounded-t-[30px] border-t border-gray-800 p-6 z-50 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex justify-center mb-4">
              <div className="w-16 h-1.5 bg-gray-800 rounded-full" />
            </div>

            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
                  <span>💬</span> Quick Support & Request
                </h3>
                <p className="text-sm text-gray-400 mt-1">
                  Tell us your requirement or issue, and we will get back shortly.
                </p>
              </div>
              <button 
                id="support-drawer-close"
                onClick={onClose}
                className="p-2 hover:bg-gray-800/80 rounded-full text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 mt-6">
              
              {/* Name */}
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-4 text-gray-400">
                  <User className="w-5 h-5" />
                </span>
                <input
                  id="support-name"
                  type="text"
                  name="name"
                  required
                  placeholder="Your Name *"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full bg-[#1e293b] text-white border-0 outline-none rounded-2xl pl-12 pr-4 py-4 text-base focus:ring-2 focus:ring-blue-500 placeholder-gray-400"
                />
              </div>

              {/* Email */}
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-4 text-gray-400">
                  <Mail className="w-5 h-5" />
                </span>
                <input
                  id="support-email"
                  type="email"
                  name="email"
                  required
                  placeholder="Your Email *"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full bg-[#1e293b] text-white border-0 outline-none rounded-2xl pl-12 pr-4 py-4 text-base focus:ring-2 focus:ring-blue-500 placeholder-gray-400"
                />
              </div>

              {/* Phone */}
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-4 text-gray-400">
                  <Phone className="w-5 h-5" />
                </span>
                <input
                  id="support-phone"
                  type="tel"
                  name="phone"
                  required
                  placeholder="Phone Number *"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full bg-[#1e293b] text-white border-0 outline-none rounded-2xl pl-12 pr-4 py-4 text-base focus:ring-2 focus:ring-blue-500 placeholder-gray-400"
                />
              </div>

              {/* Message */}
              <div className="relative">
                <span className="absolute top-4 left-4 text-gray-400">
                  <MessageSquare className="w-5 h-5" />
                </span>
                <textarea
                  id="support-message"
                  name="message"
                  required
                  rows={4}
                  placeholder="Write your message or custom requirement... *"
                  value={formData.message}
                  onChange={handleChange}
                  className="w-full bg-[#1e293b] text-white border-0 outline-none rounded-2xl pl-12 pr-4 py-4 text-base focus:ring-2 focus:ring-blue-500 placeholder-gray-400 min-h-[120px] resize-none"
                />
              </div>

              <button
                id="support-submit"
                type="submit"
                disabled={submitting}
                className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold rounded-2xl transition-all shadow-lg hover:shadow-blue-500/20 active:scale-95 flex items-center justify-center gap-2 disabled:opacity-60 disabled:pointer-events-none"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>Sending Request...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    <span>Submit Request</span>
                  </>
                )}
              </button>

            </form>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
