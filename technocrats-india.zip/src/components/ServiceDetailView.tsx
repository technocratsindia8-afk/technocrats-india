import { ArrowLeft, Sparkles, MoveRight, Layers, Award } from "lucide-react";
import { ServiceItem } from "../types";

interface ServiceDetailViewProps {
  service: ServiceItem;
  onBack: () => void;
  onOpenEnquiry: (serviceId: string) => void;
}

export default function ServiceDetailView({ service, onBack, onOpenEnquiry }: ServiceDetailViewProps) {
  return (
    <div id={`service-detail-${service.id}`} className="min-h-screen bg-[#070B1A] pb-24 text-[#EAF1FF]">
      
      {/* Top Header Navigation */}
      <div className="p-5 flex items-center justify-between gap-3 sticky top-0 bg-[#070B1A]/90 backdrop-filter backdrop-blur-lg z-30">
        <button
          id="service-detail-back"
          onClick={onBack}
          className="w-11 h-11 rounded-2xl bg-white/5 active:bg-white/10 flex items-center justify-center text-white text-xl cursor-pointer transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="flex-1 text-center">
          <h4 className="m-0 text-lg font-bold tracking-tight text-white line-clamp-1">
            {service.title}
          </h4>
          <span className="text-xs text-[#9FAFD1] mt-0.5 block">
            Custom business services
          </span>
        </div>

        <div className="w-11" /> {/* Balanced spacer */}
      </div>

      {/* Immersive Hero Card */}
      <div className="mx-5 mb-6 bg-gradient-to-br from-[#131c38] to-[#1d2b53] rounded-[30px] p-6 relative overflow-hidden shadow-xl border border-white/5">
        <div className="absolute -top-16 -right-12 w-44 h-44 bg-blue-500/10 rounded-full blur-xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-12 w-32 h-32 bg-purple-500/10 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-500/12 text-blue-400 text-xs font-semibold mb-4 border border-blue-500/10">
            <span>{service.icon}</span>
            <span>{service.badge}</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-white leading-tight mb-3">
            {service.heroTitle}
          </h1>

          <p className="text-[#b7c4e5] text-sm sm:text-base leading-relaxed">
            {service.heroText}
          </p>
        </div>
      </div>

      {/* Showcase list section */}
      {service.projects && service.projects.length > 0 && (
        <div className="mb-6">
          <div className="px-5 mb-4 flex justify-between items-center">
            <h4 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-blue-400" /> Recent Projects
            </h4>
            <span className="text-xs text-[#4da3ff] font-medium animate-pulse">
              Swipe Left →
            </span>
          </div>

          {/* Horizontal scroll cards */}
          <div className="flex gap-4 overflow-x-auto px-5 pb-3 snap-x snap-mandatory scrollbar-none scroll-smooth">
            {service.projects.map((project, idx) => (
              <div 
                key={idx}
                className="min-w-[280px] max-w-[280px] sm:min-w-[310px] sm:max-w-[310px] bg-[#151D35] rounded-3xl overflow-hidden flex-shrink-0 snap-start border border-white/5 shadow-md"
              >
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-44 object-cover"
                />
                <div className="p-4">
                  <span className="inline-block px-2.5 py-1 rounded-full bg-blue-500/12 text-[#4da3ff] text-xs font-semibold mb-2">
                    {project.tag}
                  </span>
                  <h5 className="text-lg font-bold text-white mb-2 leading-tight">
                    {project.title}
                  </h5>
                  <p className="text-[#9FAFD1] text-xs sm:text-sm leading-relaxed mb-1">
                    {project.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Feature stats summary info for detail view */}
      <div className="mx-5 mb-6 bg-[#11192F] rounded-[24px] p-5 border border-white/5">
        <h4 className="text-base font-bold text-white mb-4 tracking-tight flex items-center gap-2">
          <Layers className="w-5 h-5 text-indigo-400" /> Service Advantages
        </h4>
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3.5 bg-white/5 rounded-2xl">
            <span className="text-xl">⚡</span>
            <h6 className="font-semibold text-white mt-1 text-sm">Ultra-fast Delivery</h6>
            <p className="text-xs text-[#9FAFD1] mt-0.5">Optimized schedule delivery window</p>
          </div>
          <div className="p-3.5 bg-white/5 rounded-2xl">
            <span className="text-xl">🏆</span>
            <h6 className="font-semibold text-white mt-1 text-sm">High Return ROI</h6>
            <p className="text-xs text-[#9FAFD1] mt-0.5">Custom campaigns built to convert</p>
          </div>
          <div className="p-3.5 bg-white/5 rounded-2xl">
            <span className="text-xl">🔒</span>
            <h6 className="font-semibold text-white mt-1 text-sm">Expert Security</h6>
            <p className="text-xs text-[#9FAFD1] mt-0.5">Fully certified robust safety patterns</p>
          </div>
          <div className="p-3.5 bg-white/5 rounded-2xl">
            <span className="text-xl">💬</span>
            <h6 className="font-semibold text-white mt-1 text-sm">24/7 Live Support</h6>
            <p className="text-xs text-[#9FAFD1] mt-0.5">Access direct expert assistance</p>
          </div>
        </div>
      </div>

      {/* Interactive Call to Action */}
      <div className="mx-5 bg-gradient-to-tr from-[#16213e] to-[#12192f] rounded-[28px] p-6 text-center border border-white/10 shadow-lg shadow-blue-500/5">
        <h3 className="text-xl sm:text-2xl font-bold text-white mb-2 leading-tight">
          {service.ctaTitle}
        </h3>
        <p className="text-[#9FAFD1] text-sm leading-relaxed mb-5">
          {service.ctaText}
        </p>

        <button
          id="detail-enquiry-trigger"
          onClick={() => onOpenEnquiry(service.id)}
          className="inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold rounded-2xl transition-all hover:shadow-lg active:scale-95 cursor-pointer selection:bg-transparent"
        >
          <span>{service.ctaBtnText}</span>
          <MoveRight className="w-5 h-5" />
        </button>
      </div>

    </div>
  );
}
