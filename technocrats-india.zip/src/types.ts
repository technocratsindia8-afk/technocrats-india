export interface ServiceItem {
  id: string;
  title: string;
  icon: string;
  badge: string;
  heroTitle: string;
  heroText: string;
  ctaTitle: string;
  ctaText: string;
  ctaBtnText: string;
  category: string;
  projects?: {
    title: string;
    image: string;
    desc: string;
    tag: string;
  }[];
}

export interface VideoItem {
  title: string;
  category: string;
  id: string;
}

export interface SupportTicket {
  name: string;
  email: string;
  phone: string;
  message: string;
}

export interface ProjectEnquiry {
  name: string;
  phone: string;
  email: string;
  company: string;
  service: string;
}

export interface TestimonialItem {
  quote: string;
  author: string;
  role: string;
  avatar: string;
}

// Services derived from all the HTML files submitted by the user
export const SERVICES_DATA: ServiceItem[] = [
  {
    id: "website-design",
    title: "Website Development",
    icon: "🌐",
    badge: "Website Design & Development",
    heroTitle: "Modern Website Solutions For Business Growth",
    heroText: "We create responsive, high-performance and modern websites designed to grow your business, generate leads and build a strong digital presence.",
    ctaTitle: "Ready To Start Your Website Project?",
    ctaText: "Build your online presence with a modern responsive website.",
    ctaBtnText: "Start New Project →",
    category: "Development",
    projects: [
      {
        title: "Industry Website",
        desc: "Modern responsive industry website with comprehensive features.",
        tag: "Website Development",
        image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=600&auto=format&fit=crop"
      },
      {
        title: "Education Website",
        desc: "Modern responsive education platform with interactive learning features.",
        tag: "Website Development",
        image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=600&auto=format&fit=crop"
      },
      {
        title: "Real Estate Website",
        desc: "Modern responsive property listing website with SEO optimization.",
        tag: "Website Development",
        image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?q=80&w=600&auto=format&fit=crop"
      },
      {
        title: "Ecommerce Store",
        desc: "High converting ecommerce shopping platform with payment integration.",
        tag: "Ecommerce Solution",
        image: "https://images.unsplash.com/photo-1557838923-2985c318be48?q=80&w=600&auto=format&fit=crop"
      }
    ]
  },
  {
    id: "app-development",
    title: "App Development",
    icon: "📱",
    badge: "App Development",
    heroTitle: "Modern App Solutions For Business Growth",
    heroText: "We create responsive, high-performance and modern apps designed to grow your business, generate leads and build a strong digital presence.",
    ctaTitle: "Ready To Start Your App Project?",
    ctaText: "Build your mobile presence with a modern responsive app.",
    ctaBtnText: "Start New Project →",
    category: "Development",
    projects: [
      {
        title: "Premium E-commerce App",
        desc: "Interactive Android & iOS shopping application with smooth animations.",
        tag: "Mobile App Development",
        image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?q=80&w=600&auto=format&fit=crop"
      },
      {
        title: "SaaS Dashboard Mobile",
        desc: "Real-time key statistics tracking for cloud performance on the go.",
        tag: "Mobile App Development",
        image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=600&auto=format&fit=crop"
      }
    ]
  },
  {
    id: "software-development",
    title: "Software Development",
    icon: "💻",
    badge: "Software Development",
    heroTitle: "Modern Software Solutions For Business Growth",
    heroText: "We create responsive, high-performance and modern software solutions designed to grow your business, generate leads and build a strong digital presence.",
    ctaTitle: "Ready To Start Your Software Project?",
    ctaText: "Build your digital presence with a modern responsive software solution.",
    ctaBtnText: "Start New Project →",
    category: "Development",
    projects: [
      {
        title: "Corporate ERP System",
        desc: "Efficient custom resources pipeline management application.",
        tag: "Software Engineering",
        image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?q=80&w=600&auto=format&fit=crop"
      }
    ]
  },
  {
    id: "seo-optimization",
    title: "SEO Optimization",
    icon: "📈",
    badge: "SEO Optimization",
    heroTitle: "Improve Your Website's Search Engine Visibility",
    heroText: "Our SEO optimization services help your website rank higher on search engines, driving more organic traffic and increasing your online presence. We use proven strategies and techniques to boost your website's visibility and attract potential customers.",
    ctaTitle: "Ready To Start Your SEO Journey?",
    ctaText: "Improve your website's search engine ranking and attract more organic traffic.",
    ctaBtnText: "Start New Project →",
    category: "Marketing",
    projects: [
      {
        title: "Unsplash Real Estate SEO Boost",
        desc: "Organic discovery improved by 140% using advanced metadata algorithms.",
        tag: "SEO Strategy",
        image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=600&auto=format&fit=crop"
      }
    ]
  },
  {
    id: "podcast",
    title: "Podcast",
    icon: "🎙️",
    badge: "Podcast Production",
    heroTitle: "Discover the Latest in Podcasting",
    heroText: "Our podcast series features industry experts and thought leaders discussing the latest trends, insights, and discussions in the world of podcasting. Tune in to stay informed and inspired.",
    ctaTitle: "Ready To Start Your Podcasting Journey?",
    ctaText: "Join our podcast series and stay informed about the latest in podcasting.",
    ctaBtnText: "Start New Service →",
    category: "Branding"
  },
  {
    id: "trademark",
    title: "Trade Mark",
    icon: "™️",
    badge: "Trademark",
    heroTitle: "Protect Your Brand with Our Trademark Services",
    heroText: "Our trademark services help you secure and protect your brand identity. From filing to enforcement, we provide comprehensive support to ensure your intellectual property is safeguarded.",
    ctaTitle: "Ready To Secure Your Brand?",
    ctaText: "Join our trademark security framework and guard your commercial assets.",
    ctaBtnText: "Start New Service →",
    category: "Legal"
  },
  {
    id: "iso-certification",
    title: "ISO Certification",
    icon: "📜",
    badge: "ISO Certification",
    heroTitle: "Ensure Your Business Meets International Standards",
    heroText: "Our ISO certification services help you meet international standards and improve your business processes. From initial assessment to full certification, we provide comprehensive support to ensure your organization is compliant.",
    ctaTitle: "Ready To Start Your ISO Certification Journey?",
    ctaText: "Join our ISO certification series and stay informed about the latest in ISO compliance.",
    ctaBtnText: "Start New Service →",
    category: "Legal"
  },
  {
    id: "product-photography",
    title: "Product Photography",
    icon: "📸",
    badge: "Product Photography",
    heroTitle: "Capture Your Products in the Best Light",
    heroText: "Our professional product photography services help you showcase your items in the most appealing way. From concept to final image, we ensure your products stand out.",
    ctaTitle: "Ready To Start Your Product Photography Service?",
    ctaText: "Join our product photography series and stay informed about the latest in professional product imaging.",
    ctaBtnText: "Start New Service →",
    category: "Branding"
  },
  {
    id: "social-media-marketing",
    title: "Social Media Marketing",
    icon: "📣",
    badge: "Social Media Marketing",
    heroTitle: "Boost Your Online Presence",
    heroText: "Our strategic social media marketing services help you connect with your audience and grow your brand. From content creation to community management, we've got you covered.",
    ctaTitle: "Ready To Start Your Social Media Marketing Service?",
    ctaText: "Join our social media marketing series and stay informed about the latest in strategic social media management.",
    ctaBtnText: "Start New Service →",
    category: "Marketing"
  },
  {
    id: "vps-hosting",
    title: "VPS Cloud Hosting",
    icon: "☁️",
    badge: "VPS Cloud Hosting",
    heroTitle: "Powerful VPS Hosting Solutions",
    heroText: "Our reliable and scalable VPS hosting solutions ensure your business has the performance and uptime it needs. From content creation to community management, we've got you covered.",
    ctaTitle: "Ready To Start Your VPS Cloud Hosting Service?",
    ctaText: "Join our VPS hosting series and stay informed about the latest in scalable cloud solutions.",
    ctaBtnText: "Start New Service →",
    category: "Hosting"
  },
  {
    id: "brand-promotion",
    title: "Brand Promotion",
    icon: "🚀",
    badge: "Brand Promotion",
    heroTitle: "Effective Brand Promotion Strategies",
    heroText: "Our brand promotion services help you create a strong and memorable brand identity. From strategic marketing campaigns to creative content, we ensure your brand stands out in the competitive market.",
    ctaTitle: "Ready To Start Your Brand Promotion Campaign?",
    ctaText: "Join our brand promotion series and stay informed about the latest in effective marketing strategies.",
    ctaBtnText: "Start New Service →",
    category: "Branding"
  },
  {
    id: "event-promotion",
    title: "Event Promotion",
    icon: "🎉",
    badge: "Event Promotion",
    heroTitle: "Effective Event Promotion Strategies",
    heroText: "Our event promotion services help you create a strong and memorable event identity. From strategic marketing campaigns to creative content, we ensure your event stands out in the competitive market.",
    ctaTitle: "Ready To Start Your Event Promotion Campaign?",
    ctaText: "Join our event promotion series and stay informed about the latest in effective marketing strategies.",
    ctaBtnText: "Start New Service →",
    category: "Marketing"
  },
  {
    id: "business-email",
    title: "Business E-mail",
    icon: "📧",
    badge: "Business Email",
    heroTitle: "Professional Business Email Solutions",
    heroText: "Our business email services provide you with a professional and reliable email solution that enhances your company's communication and credibility.",
    ctaTitle: "Ready To Start Your Business Email Solution?",
    ctaText: "Join our business email series and stay informed about the latest in professional email services.",
    ctaBtnText: "Start New Service →",
    category: "Hosting"
  },
  {
    id: "whatsapp-marketing",
    title: "WhatsApp Marketing",
    icon: "💬",
    badge: "WhatsApp Marketing",
    heroTitle: "Professional WhatsApp Marketing Solutions",
    heroText: "Our WhatsApp marketing services provide you with a professional and reliable platform that enhances your company's communication, bulk broadcasting reaches, and credibility.",
    ctaTitle: "Ready To Start Your WhatsApp Marketing Solution?",
    ctaText: "Join our WhatsApp marketing series and stay informed about the latest in professional WhatsApp marketing services.",
    ctaBtnText: "Start New Service →",
    category: "Marketing"
  }
];

export const VIDEOS_DATA: VideoItem[] = [
  {
    title: "Podcast Marketing Tips",
    category: "Podcast",
    id: "7ITHQTZMvYo"
  },
  {
    title: "Subhojit Educare Promo",
    category: "Education",
    id: "NGXwMFpV0ls"
  },
  {
    title: "KareU Clinic Intro",
    category: "Beauty Clinic",
    id: "jRmQ8Ycg2iQ"
  },
  {
    title: "Meraki Weaves Showcase",
    category: "Boutique",
    id: "VAzv4j0RJq8"
  },
  {
    title: "Angel Hut School Review",
    category: "Education",
    id: "LxsCNIr9K78"
  },
  {
    title: "RGS Rehab Care Campaign",
    category: "Medical",
    id: "vek4KYyzv_g"
  },
  {
    title: "A to Z Wedding Mart Launch",
    category: "E-commerce",
    id: "XxjjHIJmTtM"
  }
];

export const TESTIMONIALS_DATA: TestimonialItem[] = [
  {
    quote: "Excellent software service, quick implementation, and continuous support!",
    author: "Satish Sharma",
    role: "Proprietor, Sharma Realties",
    avatar: "img/user.png"
  },
  {
    quote: "Highly professional IT solutions. Our App development project was completed on time with zero issues.",
    author: "Bidhisha Sen",
    role: "CEO, Educare Tech",
    avatar: "img/user.png"
  }
];

export const PORTFOLIO_CAROUSEL_DATA = [
  {
    title: "Real Estate Portal",
    desc: "Complete responsive property listing platform with SEO optimization.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=620&auto=format&fit=crop",
    tag: "Website Development"
  },
  {
    title: "Ecommerce Store",
    desc: "Modern online shopping website with payment gateway integration.",
    image: "https://images.unsplash.com/photo-1557838923-2985c318be48?q=80&w=620&auto=format&fit=crop",
    tag: "Ecommerce Development"
  },
  {
    title: "Corporate Branding",
    desc: "Full branding and digital marketing campaign for startup business.",
    image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=620&auto=format&fit=crop",
    tag: "Branding & Marketing"
  },
  {
    title: "Mobile App UI Design",
    desc: "Clean and modern mobile application interface for business growth.",
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=620&auto=format&fit=crop",
    tag: "UI/UX Design"
  },
  {
    title: "SEO Growth Campaign",
    desc: "Organic traffic boosting campaign with advanced SEO strategy.",
    image: "https://images.unsplash.com/photo-1496171367470-9ed9a91ea931?q=80&w=620&auto=format&fit=crop",
    tag: "SEO Optimization"
  }
];

export const TRUSTED_CLIENTS_DATA = [
  { name: "Apollo Clinics", image: "img/appolo.png" },
  { name: "Kurlon Mattresses", image: "img/kurlon.png" },
  { name: "Patanjali", image: "img/patanjali.png" },
  { name: "The Circle", image: "img/the-circle.jpg" },
  { name: "Spring", image: "img/spring.png" },
  { name: "Space Circle", image: "img/space-circle.png" },
  { name: "NER Labs", image: "img/ner.png" },
  { name: "Sunrise Foods", image: "img/sunrise.png" },
  { name: "Bansal Groups", image: "img/bansal.png" },
  { name: "V Hollander", image: "img/vhollander.png" },
  { name: "Genset", image: "img/genset.png" },
  { name: "Goldilocks", image: "img/goldilocks.png" }
];
