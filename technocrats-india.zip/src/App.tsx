import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Home as HomeIcon, 
  Briefcase, 
  Video, 
  PhoneCall, 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Search, 
  MessageSquare, 
  Ticket, 
  ChevronRight, 
  Star, 
  PlusCircle, 
  CalendarDays, 
  Tag, 
  ArrowRight,
  TrendingUp,
  Award,
  Play,
  PlaySquare,
  HelpCircle,
  ExternalLink,
  Laptop,
  X
} from "lucide-react";

import { 
  SERVICES_DATA, 
  VIDEOS_DATA, 
  TESTIMONIALS_DATA, 
  PORTFOLIO_CAROUSEL_DATA, 
  TRUSTED_CLIENTS_DATA,
  ServiceItem,
  VideoItem
} from "./types";

import EnquiryDrawer from "./components/EnquiryDrawer";
import SupportDrawer from "./components/SupportDrawer";
import SuccessPopup from "./components/SuccessPopup";
import ServiceDetailView from "./components/ServiceDetailView";
// @ts-ignore
import technocratsLogo from "./assets/images/technocrats_logo_user_uploaded_1781598335774.jpg";

export default function App() {
  const [activeTab, setActiveTab] = useState<"home" | "services" | "hub" | "contact">("home");
  
  // Navigation for individual service pages
  const [activeServiceId, setActiveServiceId] = useState<string | null>(null);

  // Search states
  const [servicesSearch, setServicesSearch] = useState("");
  const [videoSearch, setVideoSearch] = useState("");
  const [activeVideoCat, setActiveVideoCat] = useState("All");

  // Drawers & modals
  const [isEnquiryOpen, setIsEnquiryOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [enquiryServiceId, setEnquiryServiceId] = useState("");
  
  // Custom dialogs for home actions
  const [activeOffer, setActiveOffer] = useState<string | null>(null);
  const [activeMeetingModal, setActiveMeetingModal] = useState(false);
  const [activeCallModal, setActiveCallModal] = useState(false);
  const [lastVideoWatch, setLastVideoWatch] = useState<string | null>(null);
  const [currentPlayingVideoId, setCurrentPlayingVideoId] = useState<string | null>(null);

  // Success messages from custom forms
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Sync PWA "Continue Watching" state from LocalStorage
  useEffect(() => {
    const saved = localStorage.getItem("lastVideo");
    if (saved) {
      setLastVideoWatch(saved);
    }
  }, []);

  const handlePlayVideo = (videoId: string) => {
    localStorage.setItem("lastVideo", videoId);
    setLastVideoWatch(videoId);
    setCurrentPlayingVideoId(videoId);
  };

  const showNotification = (message: string) => {
    setSuccessMessage(message);
  };

  // Helper filter lists
  const filteredServices = SERVICES_DATA.filter(service =>
    service.title.toLowerCase().includes(servicesSearch.toLowerCase()) ||
    service.badge.toLowerCase().includes(servicesSearch.toLowerCase())
  );

  const filteredVideos = VIDEOS_DATA.filter(video => {
    const matchesSearch = video.title.toLowerCase().includes(videoSearch.toLowerCase());
    const matchesCat = activeVideoCat === "All" || video.category === activeVideoCat;
    return matchesSearch && matchesCat;
  });

  const uniqueVideoCategories = ["All", "Podcast", "Education", "Beauty Clinic", "Boutique", "Medical", "E-commerce"];

  return (
    <div id="play-store-frame" className="min-h-screen bg-[#02040a] font-sans flex items-center justify-center p-0 md:p-6 select-none">
      
      {/* Play Store Responsive Wrapper: Centered phone mockup in desktop view, full screen on mobile */}
      <div id="device-mockup" className="w-full max-w-sm sm:max-w-md md:max-w-lg bg-[#070B1A] min-h-screen md:min-h-[85vh] md:max-h-[90vh] md:rounded-[40px] shadow-2xl relative flex flex-col overflow-hidden text-[#EAF1FF] border border-gray-900">
        
        {/* Device Camera Notch / Sensor Bar (Desktop Mockup decoration) */}
        <div className="hidden md:flex justify-center items-center w-full h-8 bg-[#0b0f19] text-xs text-gray-500 font-mono select-none border-b border-gray-900 shrink-0 select-none">
          <div className="w-24 h-4 bg-black rounded-full absolute top-1 flex items-center justify-around px-2 z-50">
            <span className="w-1.5 h-1.5 bg-gray-800 rounded-full" />
            <span className="w-8 h-1 bg-gray-900 rounded-full" />
            <span className="w-2 h-2 bg-blue-900 rounded-full" />
          </div>
        </div>

        {/* View container */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden relative scrollbar-none pb-24 h-full">
          
          {/* Main conditional views */}
          {activeServiceId ? (
            /* Service detail subpage */
            <ServiceDetailView 
              service={SERVICES_DATA.find(s => s.id === activeServiceId)!}
              onBack={() => setActiveServiceId(null)}
              onOpenEnquiry={(serviceId) => {
                setEnquiryServiceId(serviceId);
                setIsEnquiryOpen(true);
              }}
            />
          ) : (
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.15 }}
                className="w-full"
              >
                {/* 1. HOME SCREEN */}
                {activeTab === "home" && (
                  <div id="home-view" className="w-full">
                    
                    {/* Header */}
                    <div className="topbar p-5 border-b border-white/5 bg-[#0f172a]/40 shrink-0">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-white rounded-xl overflow-hidden flex items-center justify-center shrink-0 shadow-md">
                            <img
                              src={technocratsLogo}
                              alt="Technocrats India"
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                          <div>
                            <h4 className="m-0 text-lg font-bold tracking-tight text-white font-display">
                              Technocrats India
                            </h4>
                            <span className="text-xs text-[#9FAFD1]">ISO 9001:2015 Certified</span>
                          </div>
                        </div>

                        {/* Floating support triggering button */}
                        <button
                          id="floating-support-btn"
                          onClick={() => setIsSupportOpen(true)}
                          className="w-11 h-11 bg-gradient-to-tr from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-500/25 active:scale-95 transition-all cursor-pointer"
                        >
                          <MessageSquare className="w-5 h-5 text-white" />
                        </button>
                      </div>
                    </div>

                    {/* Integrated Main Hero Section */}
                    <div className="hero-card m-5 bg-gradient-to-br from-[#121c37] to-[#1b2952] rounded-[28px] p-6 relative overflow-hidden shadow-xl border border-white/5">
                      <div className="absolute -top-16 -right-12 w-48 h-48 bg-blue-500/10 rounded-full blur-xl pointer-events-none" />
                      <div className="absolute -bottom-16 -left-12 w-32 h-32 bg-purple-500/10 rounded-full blur-xl pointer-events-none" />

                      <div className="relative z-10">
                        <span className="inline-block bg-blue-500/15 text-[#4da3ff] text-[11px] font-extrabold uppercase tracking-wide px-3 py-1 rounded-full mb-3 border border-blue-500/10 shadow-sm shadow-blue-500/5">
                          🏆 Trusted Growth Partner Since 2011
                        </span>
                        
                        <h1 className="text-3xl font-extrabold text-white leading-snug tracking-tight mb-2 font-display">
                          Empowering Brands with <span className="bg-gradient-to-r from-blue-400 to-[#7b61ff] bg-clip-text text-transparent">Creative Solutions</span>
                        </h1>
                        
                        <p className="text-[#c7d3f5] text-[14px] leading-relaxed mb-5">
                          Web development, custom apps, advanced SEO, branding campaigns, and complete business scaling frameworks under one secure roof.
                        </p>

                        <button
                          id="hero-start-project-btn"
                          onClick={() => {
                            setEnquiryServiceId("");
                            setIsEnquiryOpen(true);
                          }}
                          className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-400 hover:to-blue-500 text-white px-5 py-3 rounded-2xl font-bold transition-all shadow-md active:scale-95 cursor-pointer text-sm"
                        >
                          <span>Start New Project</span>
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Template 2 Quick Services grid row */}
                    <div className="px-5 mb-6">
                      <div className="flex justify-between items-center mb-3">
                        <h5 className="m-0 text-base font-bold text-white tracking-tight uppercase tracking-wider text-xs text-[#9FAFD1]">
                          ⚡ Fast Connect Actions
                        </h5>
                      </div>

                      <div className="grid grid-cols-3 gap-3">
                        {/* Call Now */}
                        <div 
                          id="quick-call-card"
                          onClick={() => setActiveCallModal(true)}
                          className="bg-[#131c31] border border-white/5 hover:border-blue-500/25 rounded-2xl p-4 text-center cursor-pointer transition-all active:scale-95 flex flex-col items-center shadow-sm"
                        >
                          <span className="text-2xl mb-1.5 flex items-center justify-center p-2.5 bg-blue-500/8 text-blue-400 rounded-xl">
                            <Phone className="w-5 h-5" />
                          </span>
                          <span className="text-[13px] font-bold text-white leading-tight">Call Team</span>
                        </div>

                        {/* Live support Chat */}
                        <div 
                          id="quick-chat-card"
                          onClick={() => setIsSupportOpen(true)}
                          className="bg-[#131c31] border border-white/5 hover:border-blue-500/25 rounded-2xl p-4 text-center cursor-pointer transition-all active:scale-95 flex flex-col items-center shadow-sm"
                        >
                          <span className="text-2xl mb-1.5 flex items-center justify-center p-2.5 bg-indigo-500/8 text-indigo-400 rounded-xl">
                            <MessageSquare className="w-5 h-5" />
                          </span>
                          <span className="text-[13px] font-bold text-white leading-tight">Team Chat</span>
                        </div>

                        {/* New project enquiry form */}
                        <div 
                          id="quick-enquiry-card"
                          onClick={() => {
                            setEnquiryServiceId("");
                            setIsEnquiryOpen(true);
                          }}
                          className="bg-[#131c31] border border-white/5 hover:border-blue-500/25 rounded-2xl p-4 text-center cursor-pointer transition-all active:scale-95 flex flex-col items-center shadow-sm"
                        >
                          <span className="text-2xl mb-1.5 flex items-center justify-center p-2.5 bg-amber-500/8 text-amber-400 rounded-xl">
                            <PlusCircle className="w-5 h-5" />
                          </span>
                          <span className="text-[13px] font-bold text-white leading-tight">New Project</span>
                        </div>

                        {/* Support ticket submission trigger */}
                        <div 
                          id="quick-ticket-card"
                          onClick={() => setIsSupportOpen(true)}
                          className="bg-[#131c31] border border-white/5 hover:border-blue-500/25 rounded-2xl p-4 text-center cursor-pointer transition-all active:scale-95 flex flex-col items-center shadow-sm"
                        >
                          <span className="text-2xl mb-1.5 flex items-center justify-center p-2.5 bg-rose-500/8 text-rose-400 rounded-xl">
                            <Ticket className="w-5 h-5" />
                          </span>
                          <span className="text-[13px] font-bold text-white leading-tight">Mkt Ticket</span>
                        </div>

                        {/* Appointment Booking */}
                        <div 
                          id="quick-appointment-card"
                          onClick={() => setActiveMeetingModal(true)}
                          className="bg-[#131c31] border border-white/5 hover:border-blue-500/25 rounded-2xl p-4 text-center cursor-pointer transition-all active:scale-95 flex flex-col items-center shadow-sm"
                        >
                          <span className="text-2xl mb-1.5 flex items-center justify-center p-2.5 bg-emerald-500/8 text-emerald-400 rounded-xl">
                            <CalendarDays className="w-5 h-5" />
                          </span>
                          <span className="text-[13px] font-bold text-white leading-tight">Meeting</span>
                        </div>

                        {/* Special Offers dialog trigger */}
                        <div 
                          id="quick-offers-card"
                          onClick={() => setActiveOffer("active")}
                          className="bg-[#131c31] border border-white/5 hover:border-blue-500/25 rounded-2xl p-4 text-center cursor-pointer transition-all active:scale-95 flex flex-col items-center shadow-sm"
                        >
                          <span className="text-2xl mb-1.5 flex items-center justify-center p-2.5 bg-purple-500/8 text-purple-400 rounded-xl">
                            <Tag className="w-5 h-5" />
                          </span>
                          <span className="text-[13px] font-bold text-white leading-tight">App Offers</span>
                        </div>
                      </div>
                    </div>

                    {/* Featured prime services row list */}
                    <div className="section px-5 mb-6">
                      <div className="section-head flex justify-between items-center mb-3">
                        <h5 className="m-0 text-base font-bold text-white flex items-center gap-2 tracking-tight">
                          💼 Premium Services
                        </h5>
                        <button 
                          onClick={() => setActiveTab("services")} 
                          className="text-xs text-[#4da3ff] hover:underline"
                        >
                          Browse All
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-3.5">
                        {SERVICES_DATA.slice(0, 4).map(service => (
                          <div 
                            key={service.id}
                            onClick={() => setActiveServiceId(service.id)}
                            className="service-card bg-[#151D35]/80 hover:bg-[#151D35] border border-white/5 hover:border-blue-500/25 rounded-2xl p-4 text-center cursor-pointer transition-transform duration-300 hover:-translate-y-1 shadow-sm flex flex-col justify-between"
                          >
                            <div>
                              <div className="service-icon w-12 h-12 bg-gradient-to-tr from-blue-500/10 to-indigo-500/10 text-white rounded-xl flex items-center justify-center mx-auto mb-3 text-2xl">
                                {service.icon}
                              </div>
                              <h6 className="font-bold text-white text-sm mb-1 line-clamp-1">{service.title}</h6>
                              <p className="text-[#9FAFD1] text-xs leading-relaxed line-clamp-2">{service.heroText}</p>
                            </div>
                            <span className="text-[11px] text-[#4da3ff] mt-2 block font-medium group">
                              Explore details →
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Stats metrics card panel */}
                    <div className="px-5 mb-6">
                      <div className="stats-card bg-gradient-to-r from-[#11192F] to-[#182543] rounded-3xl p-5 border border-white/5 shadow-md">
                        <div className="grid grid-cols-3 gap-2 text-center divide-x divide-white/5">
                          <div className="stat-box">
                            <h3 className="text-[#4da3ff] text-2xl font-extrabold tracking-tight">15+</h3>
                            <p className="m-0 text-xs text-[#9FAFD1] mt-0.5">Years Experience</p>
                          </div>
                          <div className="stat-box">
                            <h3 className="text-[#4da3ff] text-2xl font-extrabold tracking-tight">1500+</h3>
                            <p className="m-0 text-xs text-[#9FAFD1] mt-0.5">Global Clients</p>
                          </div>
                          <div className="stat-box">
                            <h3 className="text-[#4da3ff] text-2xl font-extrabold tracking-tight">5★</h3>
                            <p className="m-0 text-xs text-[#9FAFD1] mt-0.5">Google Rating</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Dynamic Auto Carousel of Recent Portfolios */}
                    <div className="px-5 mb-6">
                      <div className="section-head mb-3">
                        <h5 className="m-0 text-base font-bold text-white tracking-tight flex items-center gap-2">
                          <Star className="w-5 h-5 text-yellow-400" /> Brands We Empower
                        </h5>
                      </div>

                      {/* Infinite Scroll Portfolio Track Wrapper */}
                      <div className="overflow-hidden w-full relative rounded-3xl">
                        <div className="flex gap-4 w-max portfolio-animate">
                          
                          {/* Loop twice for smooth continuous marquee slider visual */}
                          {[...PORTFOLIO_CAROUSEL_DATA, ...PORTFOLIO_CAROUSEL_DATA].map((project, index) => (
                            <div 
                              key={index}
                              className="bg-[#151D35]/90 rounded-2xl overflow-hidden w-[240px] flex-shrink-0 border border-white/5"
                            >
                              <img src={project.image} alt={project.title} className="w-full h-32 object-cover" />
                              <div className="p-3">
                                <h6 className="font-bold text-white text-xs mb-1 line-clamp-1">{project.title}</h6>
                                <p className="text-[#9FAFD1] text-[11px] line-clamp-2 leading-relaxed">{project.desc}</p>
                                <span className="inline-block px-2 py-0.5 bg-blue-500/10 text-blue-400 text-[10px] rounded-full mt-2 font-medium">
                                  {project.tag}
                                </span>
                              </div>
                            </div>
                          ))}

                        </div>
                      </div>
                    </div>

                    {/* Testimonials Quote row slider */}
                    <div className="px-5 mb-6">
                      <div className="section-head mb-3 flex items-center gap-2">
                        <h5 className="m-0 text-base font-bold text-white">❤️ What Clients Say</h5>
                      </div>

                      <div className="space-y-3">
                        {TESTIMONIALS_DATA.map((t, idx) => (
                          <div key={idx} className="bg-[#131c31] border border-white/5 rounded-2xl p-4 flex flex-col justify-between">
                            <p className="text-gray-300 text-xs italic font-medium leading-relaxed">
                              "{t.quote}"
                            </p>
                            <div className="flex items-center gap-3 mt-3">
                              <img 
                                src={t.avatar} 
                                alt={t.author} 
                                className="w-10 h-10 rounded-full object-cover border border-blue-500/20" 
                                onError={(e) => {
                                  e.currentTarget.src = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(t.author)}&backgroundColor=0d1117&textColor=4da3ff`;
                                }}
                              />
                              <div>
                                <h6 className="text-xs font-bold text-white m-0 leading-tight">{t.author}</h6>
                                <span className="text-[10px] text-[#9FAFD1] block">{t.role}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Sliding Client Logos Marquee */}
                    <div className="px-5 mb-8">
                      <div className="section-head mb-3">
                        <h5 className="m-0 text-base font-bold text-white tracking-tight uppercase text-xs text-[#9FAFD1]">
                          🤝 Trusted By Leaders
                        </h5>
                      </div>

                      <div className="overflow-hidden relative w-full rounded-2xl bg-white/5 py-4 border border-white/5">
                        <div className="flex gap-4 w-max logo-animate items-center">
                          {[...TRUSTED_CLIENTS_DATA, ...TRUSTED_CLIENTS_DATA].map((client, idx) => (
                            <div key={idx} className="w-[65px] h-[65px] rounded-[15px] bg-[#151D35]/95 border border-white/5 flex items-center justify-center shrink-0 shadow-lg relative overflow-hidden group">
                              <img 
                                src={client.image} 
                                alt={client.name} 
                                className="w-[60px] h-[60px] object-contain bg-white rounded-[15px] p-1 transition-transform group-hover:scale-105" 
                                onError={(e) => {
                                  e.currentTarget.style.display = 'none';
                                  const fallbackSibling = e.currentTarget.nextElementSibling;
                                  if (fallbackSibling) {
                                    (fallbackSibling as HTMLElement).style.display = 'flex';
                                  }
                                }}
                              />
                              <div 
                                className="absolute inset-1 rounded-[12px] bg-gradient-to-tr from-[#131c31] to-[#1e294b] flex flex-col items-center justify-center p-1 text-center text-[10px] font-bold text-[#4da3ff] leading-none" 
                                style={{ display: 'none' }}
                              >
                                <span className="text-white text-[8px] block opacity-40 mb-1 font-sans">Brand</span>
                                <span className="line-clamp-2 leading-tight uppercase font-display tracking-tight text-xs">{client.name.split(" ")[0]}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                  </div>
                )}

                {/* 2. SERVICES LIST SCREEN */}
                {activeTab === "services" && (
                  <div id="services-view" className="p-5">
                    
                    {/* Header */}
                    <div className="mb-4">
                      <h3 className="text-2xl font-bold text-white tracking-tight uppercase tracking-wide text-sm text-[#4da3ff]">
                        Digital Catalog
                      </h3>
                      <h1 className="text-3xl font-extrabold text-white mt-1">Our Services</h1>
                      <p className="text-xs text-gray-400 mt-1">
                        Select an innovative service below to view custom blueprints and start case audits.
                      </p>
                    </div>

                    {/* Search Field */}
                    <div className="relative mb-5">
                      <input
                        id="services-search-input"
                        type="text"
                        placeholder="Search software services..."
                        value={servicesSearch}
                        onChange={(e) => setServicesSearch(e.target.value)}
                        className="w-full h-14 bg-[#151D35] text-white rounded-2xl pl-12 pr-4 border border-white/5 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none text-base transition-all placeholder:text-gray-500"
                      />
                      <Search className="w-5 h-5 absolute left-4 top-4.5 text-gray-500" />
                      {servicesSearch && (
                        <button 
                          onClick={() => setServicesSearch("")}
                          className="absolute right-4 top-4.5 text-xs text-gray-400 hover:text-white"
                        >
                          Clear
                        </button>
                      )}
                    </div>

                    {/* Dynamic Searchable Services Grid */}
                    <div className="space-y-3">
                      {filteredServices.length > 0 ? (
                        filteredServices.map(service => (
                          <div
                            key={service.id}
                            onClick={() => setActiveServiceId(service.id)}
                            className="bg-[#151D35]/80 hover:bg-[#151D35] border border-white/5 hover:border-blue-500/15 rounded-2xl p-4 flex items-center justify-between cursor-pointer transition-all duration-300"
                          >
                            <div className="flex items-center gap-4">
                              <span className="text-3xl bg-white/5 w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border border-white/5">
                                {service.icon}
                              </span>
                              <div>
                                <h5 className="text-base font-bold text-white leading-tight">
                                  {service.title}
                                </h5>
                                <p className="text-[11px] text-[#9FAFD1] mt-1 line-clamp-1 max-w-[200px] sm:max-w-xs leading-relaxed">
                                  {service.heroText}
                                </p>
                              </div>
                            </div>
                            
                            <ChevronRight className="w-5 h-5 text-blue-400 shrink-0 ml-2" />
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-10 bg-white/5 rounded-2xl">
                          <p className="text-gray-400 text-sm">No matches found for "{servicesSearch}".</p>
                          <button 
                            onClick={() => setServicesSearch("")}
                            className="text-xs text-[#4da3ff] mt-2 underline"
                          >
                            View all services
                          </button>
                        </div>
                      )}
                    </div>

                  </div>
                )}

                {/* 3. TECHNOCRATS HUB / OTT VIDEO PLAYER */}
                {activeTab === "hub" && (
                  <div id="hub-view" className="p-0">
                    
                    {/* Header */}
                    <div className="p-5 pb-2">
                      <h3 className="text-2xl font-bold text-white uppercase tracking-wide text-xs text-[#4da3ff]">
                        Corporate Feed
                      </h3>
                      <h1 className="text-3xl font-extrabold text-white mt-1">Technocrats Hub</h1>
                      <p className="text-xs text-gray-400 mt-1">
                        Watch expert podcasts, client business showcase videos, and growth reviews.
                      </p>
                    </div>

                    {/* Featured Video Card (Hero visual) */}
                    <div className="m-5 rounded-3xl overflow-hidden relative h-52 bg-[#151D35] shadow-xl border border-white/5">
                      <img 
                        src={`https://img.youtube.com/vi/${VIDEOS_DATA[0].id}/hqdefault.jpg`} 
                        alt="Featured thumb" 
                        className="w-full h-full object-cover" 
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent p-5 flex flex-col justify-end">
                        <span className="inline-block bg-blue-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full w-max mb-2">
                          FEATURED VIDEO
                        </span>
                        
                        <h2 className="text-lg font-bold text-white mb-2 line-clamp-1 leading-tight">
                          {VIDEOS_DATA[0].title}
                        </h2>
                        
                        <p className="text-[#9FAFD1] text-xs leading-relaxed max-w-xs mb-3 line-clamp-2">
                          Join our expert panel discusses podcasts marketing hacks and social engine campaigns.
                        </p>

                        <button 
                          onClick={() => handlePlayVideo(VIDEOS_DATA[0].id)}
                          className="py-2.5 px-4 bg-gradient-to-r from-blue-500 to-indigo-600 font-semibold text-xs text-white rounded-xl w-max flex items-center gap-1.5 active:scale-95 active:bg-blue-500 transition-all cursor-pointer"
                        >
                          <Play className="w-4 h-4 fill-white" />
                          <span>Watch Now</span>
                        </button>
                      </div>
                    </div>

                    {/* Search Field */}
                    <div className="px-5 mb-4">
                      <div className="relative">
                        <input
                          id="hub-video-search"
                          type="text"
                          placeholder="Search content or topics..."
                          value={videoSearch}
                          onChange={(e) => setVideoSearch(e.target.value)}
                          className="w-full h-12 bg-[#151D35] text-white rounded-xl pl-10 pr-4 outline-none border border-white/5 focus:border-blue-500 text-sm placeholder:text-gray-500"
                        />
                        <Search className="w-4 h-4 absolute left-3.5 top-4 text-gray-500" />
                      </div>
                    </div>

                    {/* Horizontal scroll category categories */}
                    <div className="category-wrap flex gap-2 overflow-x-auto px-5 mb-5 scrollbar-none">
                      {uniqueVideoCategories.map(cat => (
                        <button
                          key={cat}
                          onClick={() => setActiveVideoCat(cat)}
                          className={`px-4 py-2 text-xs font-semibold rounded-full whitespace-nowrap transition-colors cursor-pointer ${
                            activeVideoCat === cat 
                              ? "bg-blue-500 text-white shadow-md shadow-blue-500/10" 
                              : "bg-[#151D35] text-gray-400 hover:text-white"
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>

                    {/* Continue watching box if cookies say so */}
                    {lastVideoWatch && (
                      <div className="px-5 mb-5">
                        <div className="p-3 bg-gradient-to-r from-[#151d35] to-[#121c37] border border-blue-500/10 rounded-2xl flex items-center justify-between shadow-sm">
                          <div className="flex items-center gap-3">
                            <span className="text-xl">🎬</span>
                            <div>
                              <h6 className="text-xs font-bold text-white m-0">Continue Watching</h6>
                              <p className="text-[10px] text-gray-400 m-0">Resume your last watched video session</p>
                            </div>
                          </div>
                          
                          <button
                            onClick={() => handlePlayVideo(lastVideoWatch)}
                            className="bg-blue-500/20 text-[#4da3ff] hover:bg-blue-500 text-xs py-1.5 px-3 rounded-lg flex items-center font-medium transition-colors"
                          >
                            Resume
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Video list Grid */}
                    <div className="px-5 mb-6">
                      <h4 className="text-sm font-bold text-[#9FAFD1] mb-3 uppercase tracking-wider">
                        Trending Portfolio Clips
                      </h4>
                      
                      <div className="grid grid-cols-2 gap-3.5">
                        {filteredVideos.map(video => (
                          <div
                            key={video.id}
                            onClick={() => handlePlayVideo(video.id)}
                            className="bg-[#151D35] rounded-2xl overflow-hidden cursor-pointer border border-white/5 hover:border-blue-500/10 shadow-sm transition-transform duration-300 hover:scale-[1.02]"
                          >
                            <div className="h-24 relative overflow-hidden bg-gray-800">
                              <img 
                                src={`https://img.youtube.com/vi/${video.id}/hqdefault.jpg`} 
                                alt={video.title} 
                                className="w-full h-full object-cover"
                              />
                              <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                                <span className="bg-black/60 p-2 rounded-full text-white">
                                  <Play className="w-4 h-4 fill-white text-white ml-0.5" />
                                </span>
                              </div>
                            </div>

                            <div className="p-2.5">
                              <h6 className="text-xs font-bold text-white line-clamp-1 mb-0.5 leading-tight">
                                {video.title}
                              </h6>
                              <span className="text-[9px] text-[#9FAFD1] bg-white/5 px-2 py-0.5 rounded-full inline-block">
                                {video.category}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>

                      {filteredVideos.length === 0 && (
                        <div className="text-center py-10 bg-white/5 rounded-2xl mt-4">
                          <p className="text-gray-400 text-sm">No videos found matching category or keyword.</p>
                        </div>
                      )}
                    </div>

                  </div>
                )}

                {/* 4. CONTACTS INFO SCREEN */}
                {activeTab === "contact" && (
                  <div id="contact-view" className="p-5">
                    
                    {/* Header */}
                    <div className="mb-4">
                      <h3 className="text-2xl font-bold text-white uppercase tracking-wide text-xs text-[#4da3ff]">
                        Customer Relations
                      </h3>
                      <h1 className="text-3xl font-extrabold text-white mt-1">Contact Us</h1>
                      <p className="text-gray-400 text-xs mt-1 leading-relaxed">
                        Have custom requirements? Submit details or reach us in real time.
                      </p>
                    </div>

                    <div className="space-y-4">
                      
                      {/* Address card */}
                      <div className="bg-[#151D35]/80 rounded-[22px] p-4 flex gap-4 items-start border border-white/5">
                        <span className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 text-xl flex items-center justify-center shrink-0">
                          <MapPin className="w-5 h-5" />
                        </span>
                        <div>
                          <h5 className="text-sm font-bold text-white mb-1">Corporate Address</h5>
                          <p className="text-xs text-[#9FAFD1] leading-relaxed">
                            IC-7, Baguihati<br />
                            Kolkata – 700059<br />
                            West Bengal, India
                          </p>
                        </div>
                      </div>

                      {/* Messaging card */}
                      <div className="bg-[#151D35]/80 rounded-[22px] p-4 flex gap-4 items-center justify-between border border-white/5">
                        <div className="flex gap-4 items-start">
                          <span className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 text-xl flex items-center justify-center shrink-0">
                            <Mail className="w-5 h-5" />
                          </span>
                          <div>
                            <h5 className="text-sm font-bold text-white mb-1">Send Message</h5>
                            <a href="mailto:info@technocratsindia.org" className="text-xs text-blue-400 hover:underline">
                              info@technocratsindia.org
                            </a>
                          </div>
                        </div>

                        <a 
                          href="mailto:info@technocratsindia.org"
                          className="bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs py-2 px-4 rounded-xl shadow-md transition-colors"
                        >
                          Email Us
                        </a>
                      </div>

                      {/* Phone Inquiry */}
                      <div className="bg-[#151D35]/80 rounded-[22px] p-4 flex gap-4 items-center justify-between border border-white/5">
                        <div className="flex gap-4 items-start">
                          <span className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 text-xl flex items-center justify-center shrink-0">
                            <Phone className="w-5 h-5" />
                          </span>
                          <div>
                            <h5 className="text-sm font-bold text-white mb-1">Sales Hotline</h5>
                            <a href="tel:+919830795700" className="text-xs text-emerald-400 font-medium hover:underline">
                              +91 9830795700
                            </a>
                          </div>
                        </div>

                        <a 
                          href="tel:+919830795700"
                          className="bg-[#10b981] hover:bg-[#059669] text-white font-semibold text-xs py-2 px-4 rounded-xl shadow-md transition-colors"
                        >
                          Call Now
                        </a>
                      </div>

                      {/* Customer Support Line */}
                      <div className="bg-[#151D35]/80 rounded-[22px] p-4 flex gap-4 items-center justify-between border border-white/5">
                        <div className="flex gap-4 items-start">
                          <span className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 text-xl flex items-center justify-center shrink-0">
                            <Phone className="w-5 h-5" />
                          </span>
                          <div>
                            <h5 className="text-sm font-bold text-white mb-1">Customer Support</h5>
                            <a href="tel:+919830795705" className="text-xs text-amber-400 font-medium hover:underline">
                              +91 9830795705
                            </a>
                          </div>
                        </div>

                        <a 
                          href="tel:+919830795705"
                          className="bg-[#d97706] hover:bg-[#b45309] text-white font-semibold text-xs py-2 px-4 rounded-xl shadow-md"
                        >
                          Call Care
                        </a>
                      </div>

                      {/* Working times */}
                      <div className="bg-[#11192F]/60 rounded-[22px] p-4 flex gap-4 items-start border border-white/5">
                        <span className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 text-xl flex items-center justify-center shrink-0">
                          <Clock className="w-5 h-5" />
                        </span>
                        <div>
                          <h5 className="text-sm font-bold text-white mb-1">Working Hours</h5>
                          <p className="text-xs text-[#9FAFD1] leading-relaxed">
                            Monday - Saturday<br />
                            10:30am - 7:00pm
                          </p>
                        </div>
                      </div>

                    </div>

                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          )}

        </div>

        {/* =======================================
           IMMERSIVE CUSTOM NAV BOTTOM TABS 
        ======================================= */}
        <div className="bottom-nav absolute left-4 right-4 bottom-4 bg-[#10182c]/95 backdrop-filter backdrop-blur-lg rounded-2xl py-3 px-3 flex justify-around items-center border border-white/5 shadow-2xl z-40 shrink-0">
          
          {/* Home Tab */}
          <button
            id="nav-tab-home"
            onClick={() => {
              setActiveServiceId(null);
              setActiveTab("home");
            }}
            className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
              activeTab === "home" && !activeServiceId ? "text-blue-400" : "text-gray-400"
            }`}
          >
            <HomeIcon className="w-5 h-5" />
            <span className="text-[10px] font-semibold">Home</span>
          </button>

          {/* Services Tab */}
          <button
            id="nav-tab-services"
            onClick={() => {
              setActiveServiceId(null);
              setActiveTab("services");
            }}
            className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
              activeTab === "services" || activeServiceId ? "text-blue-400" : "text-gray-400"
            }`}
          >
            <Briefcase className="w-5 h-5" />
            <span className="text-[10px] font-semibold">Services</span>
          </button>

          {/* Hub Tab */}
          <button
            id="nav-tab-hub"
            onClick={() => {
              setActiveServiceId(null);
              setActiveTab("hub");
            }}
            className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
              activeTab === "hub" && !activeServiceId ? "text-blue-400" : "text-gray-400"
            }`}
          >
            <Video className="w-5 h-5" />
            <span className="text-[10px] font-semibold">Hub</span>
          </button>

          {/* Contact Tab */}
          <button
            id="nav-tab-contact"
            onClick={() => {
              setActiveServiceId(null);
              setActiveTab("contact");
            }}
            className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
              activeTab === "contact" && !activeServiceId ? "text-blue-400" : "text-gray-400"
            }`}
          >
            <PhoneCall className="w-5 h-5" />
            <span className="text-[10px] font-semibold">Contact</span>
          </button>

        </div>

      </div>

      {/* =======================================
         CUSTOM MODALS (Dialog actions)
      ======================================= */}
      
      {/* 1. Youtube overlay popup dialog */}
      <AnimatePresence>
        {currentPlayingVideoId && (
          <div id="youtube-overlay-popup" className="fixed inset-0 bg-black/95 flex items-center justify-center z-[99999] p-4 pointer-events-auto">
            <button 
              id="youtube-overlay-close"
              onClick={() => setCurrentPlayingVideoId(null)}
              className="absolute top-4 right-4 text-white hover:text-red-400 p-2.5 bg-white/5 rounded-full"
            >
              <X className="w-6 h-6" />
            </button>
            <div className="w-full max-w-2xl aspect-video rounded-2xl overflow-hidden border border-gray-800">
              <iframe
                id="youtube-frame-renderer"
                width="100%"
                height="100%"
                src={`https://www.youtube.com/embed/${currentPlayingVideoId}?autoplay=1&rel=0`}
                title="Player Content"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
              />
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* 2. Offers coupon modal */}
      <AnimatePresence>
        {activeOffer && (
          <div id="coupon-overlay-popup" className="fixed inset-0 flex items-center justify-center p-4 z-[99999]">
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 0.6 }} 
              exit={{ opacity: 0 }} 
              onClick={() => setActiveOffer(null)} 
              className="absolute inset-0 bg-black" 
            />
            <motion.div 
              initial={{ scale: 0.9 }} 
              animate={{ scale: 1 }} 
              exit={{ scale: 0.9 }} 
              className="bg-[#111827] rounded-3xl p-6 text-center max-w-sm w-full relative z-10 border border-purple-500/20 shadow-2xl"
            >
              <span className="text-4xl">🎁</span>
              <h3 className="text-xl font-bold text-white mt-1 mb-2 font-display">Special App Offers!</h3>
              <div className="p-3 bg-gradient-to-r from-purple-500/10 to-indigo-500/10 rounded-xl border border-purple-500/10 my-4 text-left">
                <span className="text-xs text-purple-400 font-extrabold uppercase tracking-widest block">Limited Voucher</span>
                <p className="text-white text-sm font-bold mt-1">FREE Domain & Cloud VPS Backup</p>
                <p className="text-[#9FAFD1] text-xs mt-1">Applicable on customized website development or high quality software audit packages.</p>
              </div>
              <button 
                onClick={() => {
                  setActiveOffer(null);
                  setEnquiryServiceId("website-design");
                  setIsEnquiryOpen(true);
                }}
                className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-semibold rounded-xl text-sm transition-transform active:scale-95 cursor-pointer mb-2"
              >
                Claim This Offer Now
              </button>
              <button onClick={() => setActiveOffer(null)} className="text-xs text-gray-500 hover:text-white mt-1 cursor-pointer">
                Maybe later
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 3. Call Hotline confirmation modal */}
      <AnimatePresence>
        {activeCallModal && (
          <div id="call-confirmation-popup" className="fixed inset-0 flex items-center justify-center p-4 z-[99999]">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 0.6 }} exit={{ opacity: 0 }} onClick={() => setActiveCallModal(false)} className="absolute inset-0 bg-black" />
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} className="bg-[#111827] rounded-3xl p-6 text-center max-w-sm w-full relative z-10 border border-gray-800 shadow-2xl">
              <span className="text-3xl">📞</span>
              <h3 className="text-lg font-bold text-white mt-2 mb-1">Sales & Business Hotline</h3>
              <p className="text-xs text-[#9FAFD1] leading-relaxed mb-4">You are about to dial our primary support department:</p>
              <a href="tel:+919830795700" className="block p-3.5 bg-white/5 hover:bg-white/10 text-[#4da3ff] font-bold text-sm tracking-wider rounded-xl mb-4 font-display">
                +91 9830795700
              </a>
              <div className="flex gap-3">
                <button onClick={() => setActiveCallModal(false)} className="flex-1 py-3 bg-gray-800 text-white rounded-xl text-xs font-semibold cursor-pointer">
                  Cancel
                </button>
                <a href="tel:+919830795700" onClick={() => setActiveCallModal(false)} className="flex-1 py-3 bg-blue-600 text-white text-center rounded-xl text-xs font-bold shadow-md cursor-pointer select-none">
                  Dial Call
                </a>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 4. Meeting Scheduler popup dialog */}
      <AnimatePresence>
        {activeMeetingModal && (
          <div id="appointment-booking-popup" className="fixed inset-0 flex items-center justify-center p-4 z-[99999]">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 0.6 }} exit={{ opacity: 0 }} onClick={() => setActiveMeetingModal(false)} className="absolute inset-0 bg-black" />
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} className="bg-[#111827] rounded-3xl p-6 text-center max-w-sm w-full relative z-10 border border-gray-800 shadow-2xl">
              <span className="text-3xl">🗓️</span>
              <h3 className="text-lg font-bold text-white mt-2 mb-1">Book a Business Meeting</h3>
              <p className="text-xs text-[#9FAFD1] leading-relaxed mb-4">Select your meeting choice to connect with our consultants:</p>
              <div className="space-y-2 mb-5">
                <div onClick={() => {
                  setActiveMeetingModal(false);
                  showNotification("Meeting request saved! We will coordinate a virtual session via Zoom/Google Meet.");
                }} className="p-3 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl text-left cursor-pointer transition-all active:scale-98">
                  <h6 className="text-[13px] font-bold text-white m-0">Online Meeting Video session</h6>
                  <p className="text-[10px] text-gray-400 m-0 mt-0.5">Zoom, MSTeams or Google Meet session</p>
                </div>
                <div onClick={() => {
                  setActiveMeetingModal(false);
                  showNotification("Meeting request saved! We will coordinate an offline session at our Kolkata Baguihati office.");
                }} className="p-3 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl text-left cursor-pointer transition-all active:scale-98">
                  <h6 className="text-[13px] font-bold text-white m-0">Offline Physical meeting</h6>
                  <p className="text-[10px] text-gray-400 m-0 mt-0.5">Kolkata baguihati headquarters consultation</p>
                </div>
              </div>
              <button onClick={() => setActiveMeetingModal(false)} className="text-xs text-gray-500 hover:text-white select-none shrink-0 cursor-pointer">
                Cancel
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Primary Slide Drawers */}
      <EnquiryDrawer 
        isOpen={isEnquiryOpen}
        onClose={() => {
          setIsEnquiryOpen(false);
          setEnquiryServiceId("");
        }}
        selectedServiceId={enquiryServiceId}
        onSuccess={showNotification}
      />

      <SupportDrawer 
        isOpen={isSupportOpen}
        onClose={() => setIsSupportOpen(false)}
        onSuccess={showNotification}
      />

      {/* Floating Success popup prompt */}
      <SuccessPopup 
        message={successMessage}
        onClose={() => setSuccessMessage(null)}
      />

    </div>
  );
}
